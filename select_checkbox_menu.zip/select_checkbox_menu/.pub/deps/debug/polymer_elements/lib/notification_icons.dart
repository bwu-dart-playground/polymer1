// DO NOT EDIT: auto-generated with `pub run custom_element_apigen:update`

/// Dart API for the polymer element `notification_icons`.
@HtmlImport('notification_icons_nodart.html')
library polymer_elements.lib.src.iron_icons.notification_icons;

import 'dart:html';
import 'dart:js' show JsArray, JsObject;
import 'package:web_components/web_components.dart';
import 'package:polymer_interop/polymer_interop.dart';
import 'iron_icon.dart';
import 'iron_iconset_svg.dart';
