// DO NOT EDIT: auto-generated with `pub run custom_element_apigen:update`

/// Dart API for the polymer element `google_apis`.
@HtmlImport('google_apis_nodart.html')
library polymer_elements.lib.src.google_apis.google_apis;

import 'dart:html';
import 'dart:js' show JsArray, JsObject;
import 'package:web_components/web_components.dart';
import 'package:polymer_interop/polymer_interop.dart';
import 'google_client_loader.dart';
import 'google_legacy_loader.dart';
import 'google_maps_api.dart';
import 'google_plusone_api.dart';
import 'google_realtime_api.dart';
import 'google_youtube_api.dart';
