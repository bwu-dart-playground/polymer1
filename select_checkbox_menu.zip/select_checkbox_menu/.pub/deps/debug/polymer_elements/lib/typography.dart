// DO NOT EDIT: auto-generated with `pub run custom_element_apigen:update`

/// Dart API for the polymer element `typography`.
@HtmlImport('typography_nodart.html')
library polymer_elements.lib.src.paper_styles.typography;

import 'dart:html';
import 'dart:js' show JsArray, JsObject;
import 'package:web_components/web_components.dart';
import 'package:polymer_interop/polymer_interop.dart';
import 'roboto.dart';
