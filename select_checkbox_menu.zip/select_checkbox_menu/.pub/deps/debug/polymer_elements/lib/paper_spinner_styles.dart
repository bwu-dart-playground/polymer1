// DO NOT EDIT: auto-generated with `pub run custom_element_apigen:update`

/// Dart API for the polymer element `paper_spinner_styles`.
@HtmlImport('paper_spinner_styles_nodart.html')
library polymer_elements.lib.src.paper_spinner.paper_spinner_styles;

import 'dart:html';
import 'dart:js' show JsArray, JsObject;
import 'package:web_components/web_components.dart';
import 'package:polymer_interop/polymer_interop.dart';
