// Copyright (c) 2015, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.
library polymer.src.js.js_undefined;

import 'dart:js';

/// TODO(jakemac): Remove once we get
/// https://github.com/dart-lang/sdk/issues/24088.
final polymerDartUndefined = context['Polymer']['Dart']['undefined'];
